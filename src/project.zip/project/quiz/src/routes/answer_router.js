import express from "express";
import AnswerController from "../controllers/answerController.js";

const router = express.Router();

router.post("/", AnswerController.createAnswer);
router.get("/:id", AnswerController.getAnswerById);
router.get("/question/:question_id", AnswerController.getAnswersByQuestionId);
router.put("/:id/text", AnswerController.updateAnswerText);
router.put("/:id/correctness", AnswerController.updateAnswerCorrectness);
router.delete("/:id", AnswerController.deleteAnswer);
router.post('/submit', AnswerController.submitAnswer); 
router.get("/student-answer/:student_id/:quiz_id/:question_id",AnswerController. getStudentAnswerForQuestion);

export default router;
