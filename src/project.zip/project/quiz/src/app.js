import express from 'express';
import teacherRoutes from './routes/teacherRoutes.js';
import studentRouters from  './routes/studentRoutes.js';
import question_router from './routes/question_router.js';
import answer_router from './routes/answer_router.js';
import quizRoutes from './routes/quizRoutes.js';
import resultRoutes from './routes/resultRoutes.js';
import appConfig from './config/appConfig.js';
import cookieParser from 'cookie-parser';
import { Server } from 'socket.io';
import http from 'http';
import { createServer } from 'http';

//Imen : configuring the app 
const PORT = process.env.PORT || 7000 ;
const app = express();
appConfig(app);
 

 // Crée le serveur HTTP
const server = createServer(app);
/*
// Crée le serveur Socket.IO avec configuration CORS
const io = new Server(server, {
  cors: {
    origin: '*', // pour tests en local, autorise tout
    methods: ['GET', 'POST'],
  },
});

// Liste des étudiants connectés
let students = [];

io.on('connection', (socket) => {
  console.log('Un client est connecté avec socketId:', socket.id);

  students.push(socket.id);

  socket.on('disconnect', () => {
    console.log('Un client est déconnecté', socket.id);
    students = students.filter(id => id !== socket.id);
  });
});

// Simulation de la soumission du quiz
const simulateQuizSubmission = () => {
  const quizId = 1;
  const teacherId = 1;

  console.log(`Soumission simulée du quiz: ${quizId} par l'enseignant ${teacherId}`);

  students.forEach(studentSocketId => {
    io.to(studentSocketId).emit('new-notification', {
      message: `Un nouveau quiz a été soumis par l'enseignant ${teacherId}. Quiz ID: ${quizId}.`,
      quizId: quizId,
    });
  });
};

// Appel unique après 4s
setTimeout(simulateQuizSubmission, 4000);

// Lancer le serveur*/



//Imen : Routes
app.use(cookieParser()); 
app.use('/api/teachers',teacherRoutes);
app.use('/api/students',studentRouters);
app.use('/api/quizzes',quizRoutes);
app.use('/api/questions', question_router);
app.use('/api/answers', answer_router); 
app.use('/api/result', resultRoutes); 
export default app ;
